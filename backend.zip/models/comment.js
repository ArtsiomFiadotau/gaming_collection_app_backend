'use strict';
import { Model } from 'sequelize';
export default (sequelize, DataTypes) => {
  class Comment extends Model {
    static associate(models) {
      Comment.belongsTo(models.User,
        {
        foreignKey: 'userId'
      }
      );
      Comment.belongsTo(models.Review,
        {
        foreignKey: 'reviewId'
      }
      );
    }
  }
  Comment.init({
    commentId: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    userId: DataTypes.INTEGER,
    commentText: DataTypes.STRING(1000),
    reviewId: DataTypes.INTEGER,
    }, {
    sequelize,
    modelName: 'Comment',
  });
 
  return Comment;
};